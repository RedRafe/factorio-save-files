-- List of join messages and their weights. Default is 10.
return {
    {'And remember.. Keep Calm And Spaghetti!', 50},
    {'Press F to pay respects to the "Press F to pay respect" message', 3},
    {'Not sure what to do? Ask Newcott.', 1},
    {'Stick and move, stick and move', 10},
    {'Fly like a butterfly, sting like a bee', 10},
    {"These are not the bots you're looking for", 10}
}
