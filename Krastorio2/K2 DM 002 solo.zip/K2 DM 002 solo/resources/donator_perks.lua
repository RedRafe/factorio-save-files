return {
    rank = 0x1,
    train = 0x2
}
