local Public = {}

function Public.default_close(style)
    style.height = 28
    style.font = 'default-semibold'
    style.font_color = {0, 0, 0}
end

return Public
