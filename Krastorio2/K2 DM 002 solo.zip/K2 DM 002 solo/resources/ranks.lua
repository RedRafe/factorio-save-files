-- When adding/removing/changing ranks, rank_system has a migrate_data() function you can use to adjust the existing data.
return {
    probation = -10,
    guest = 0,
    auto_trusted = 10,
    regular = 20,
    admin = 30,
}
