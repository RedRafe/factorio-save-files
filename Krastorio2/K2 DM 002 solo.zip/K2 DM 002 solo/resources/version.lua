global.redmew_version = nil
