return require 'map_gen.maps.danger_ores.presets.danger_ores'
