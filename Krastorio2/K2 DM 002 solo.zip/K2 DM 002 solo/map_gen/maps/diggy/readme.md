## RedMew - Diggy, Custom Scenario

The documentation for Diggy has moved to https://github.com/Refactorio/RedMew/wiki/Map-guide%3A-Diggy
