return {
    voting = 1,
    moving = 2,
    down = 3,
    pause = 4
}