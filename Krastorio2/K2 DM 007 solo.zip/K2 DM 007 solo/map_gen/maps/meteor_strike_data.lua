local data =
{
    {
        weight = 1,
        thresholds =
        {
            {value = 400, name = nil},
            {value = 500, name = "iron-ore"},
            {value = 600, name = "copper-ore"},
            {value = 700, name = "coal"},
            {value = 800, name = "stone"},
        }
    }
}


local function process_data()


end

process_data()
return data
