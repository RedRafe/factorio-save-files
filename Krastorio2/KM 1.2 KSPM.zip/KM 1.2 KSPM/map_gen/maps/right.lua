return function(x, y)
    return not (x < -150 or y > 32 or y < -568)
end
