-- Map setup instructions in https://github.com/Refactorio/RedMew/wiki/Map-guide%3A-Tetris

return require 'map_gen.maps.tetris.scenario'
