return require 'map_gen.maps.danger_ores.presets.terraforming_danger_ore'
