local Session = require 'utils.datastore.session_data'
local Modifiers = require 'player_modifiers'
local Server = require 'utils.server'
local Color = require 'utils.color_presets'
local Event = require 'utils.event'
local Global = require 'utils.global'
local Gui = require 'utils.gui'

local bottom_button_gui = Gui.uid_name()
local clear_corpse_main_button_name = Gui.uid_name()
local bottom_quickbar_button_name = Gui.uid_name()

local Public = {}

local this = {
    activate_custom_buttons = false,
    bottom_right = false,
    bottom_button_one = nil,
    bottom_button_two = nil
}

Global.register(
    this,
    function(t)
        this = t
    end
)

local function create_frame(player, rebuild)
    local gui = player.gui
    local frame = gui.screen[bottom_button_gui]
    if frame and frame.valid then
        if rebuild then
            frame.destroy()
        else
            return frame
        end
    end

    frame =
        player.gui.screen.add {
        type = 'frame',
        name = bottom_button_gui,
        direction = 'vertical'
    }
    frame.style.padding = 3
    frame.style.minimal_height = 96
    frame.style.top_padding = 4

    local inner_frame =
        frame.add {
        type = 'frame',
        direction = 'vertical'
    }
    inner_frame.style = 'quick_bar_inner_panel'

    return frame
end

local function get_frame(player)
    local gui = player.gui
    local frame = gui.screen[bottom_button_gui]
    if frame and frame.valid then
        return frame
    end
end

local function set_location(player)
    local frame = create_frame(player)
    local resolution = player.display_resolution
    local scale = player.display_scale

    if this.bottom_right then
        frame.location = {
            x = (resolution.width / 2) - ((54 + -528) * scale),
            y = (resolution.height - (96 * scale))
        }
    else
        local experimental = get_game_version()
        if experimental then
            frame.location = {
                x = (resolution.width / 2) - ((54 + 445) * scale),
                y = (resolution.height - (96 * scale))
            }
        else
            frame.location = {
                x = (resolution.width / 2) - ((54 + 258) * scale),
                y = (resolution.height - (96 * scale))
            }
        end
    end
end

--- Activates the custom buttons
---@param boolean
function Public.activate_custom_buttons(value)
    if value then
        this.activate_custom_buttons = value
    else
        this.activate_custom_buttons = false
    end
end

--- Sets the buttons to be aligned bottom right
---@param boolean
function Public.bottom_right(value)
    if value then
        this.bottom_right = value
    else
        this.bottom_right = false
    end
end

function Public.add_asset(player, asset)
    local frame = get_frame(player)
    if not type(asset) == 'table' then
        return error('Bottom_gui.add_asset requires a table.', 2)
    end
    if not (asset.sprite and asset.name and asset.tooltip) then
        return error('Bottom_gui.add_asset requires a table.', 2)
    end

    frame.add {
        type = 'sprite-button',
        sprite = asset.sprite,
        name = asset.name,
        tooltip = {'' .. asset.tooltip .. ''},
        style = 'quick_bar_page_button'
    }

    --[[ frame.add {
        type = 'sprite-button',
        sprite = 'entity/behemoth-biter',
        name = clear_corpse_button_name,
        tooltip = {'commands.clear_corpse'},
        style = 'quick_bar_page_button'
    } ]]
    local bottom_quickbar_button =
        frame.add {
        type = 'sprite-button',
        name = bottom_quickbar_button_name,
        style = 'quick_bar_page_button'
    }
end

Event.add(
    defines.events.on_player_joined_game,
    function(event)
        local player = game.players[event.player_index]

        if this.activate_custom_buttons then
            set_location(player)
        end
    end
)

Event.add(
    defines.events.on_player_display_resolution_changed,
    function(event)
        local player = game.get_player(event.player_index)
        if this.activate_custom_buttons then
            set_location(player)
        end
    end
)

Event.add(
    defines.events.on_player_respawned,
    function(event)
        local player = game.get_player(event.player_index)
        if this.activate_custom_buttons then
            set_location(player)
        end
    end
)

Event.add(
    defines.events.on_player_died,
    function(event)
        local player = game.get_player(event.player_index)
        if this.activate_custom_buttons then
            local frame = player.gui.screen[bottom_button_gui]
            if frame and frame.valid then
                frame.destroy()
            end
        end
    end
)

Event.add(
    defines.events.on_player_display_scale_changed,
    function(event)
        local player = game.get_player(event.player_index)
        if this.activate_custom_buttons then
            set_location(player)
        end
    end
)

return Public
