-- Map by Jayefuu, grilledham, R.Nukem and Soggs

-- Notes:
-- - We recommend playing with RSO to force expansion by rail
-- - If playing with mods, do not use FARL, the rail placing mechanic will not work with this map

require 'map_gen.maps.rail_grid.scenario_setup'
require 'map_gen.maps.rail_grid.rail_grid_restrictions'
return require 'map_gen.maps.rail_grid.map'
