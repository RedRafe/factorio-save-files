return function(x, y)
    return not (x > 100 or y > 200 or y < -200)
end
